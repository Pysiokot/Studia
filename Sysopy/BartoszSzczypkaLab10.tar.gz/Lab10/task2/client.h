#include <signal.h>

char* name;
char* connectType;
char* address;
int socketFD;
int port;