public class Filozof implements Runnable{
    Widelec w1, w2;
    int dummy;
    int ID;

    public Filozof(Widelec w1, Widelec w2, int ID){
        this.w1 = w1;
        this.w2 = w2;
        this.ID = ID;
    }

    public void jedz(){
        System.out.println(ID + " Filozof je");
    }

    public void mysl(){
        System.out.println(ID + " Filozof mysli");
    }

    public void wezWidelec(){
        System.out.println(ID + " Filozof podnosi widelec 1");
        w1.wez();
        System.out.println(ID + " Filozof podnosi widelec 2");
        w2.wez();
    }

    public void odloz(){
        System.out.println(ID + " Filozof odklada widelec 1");
        w1.odloz();
        System.out.println(ID + " Filozof odklada widelec 2");
        w2.odloz();
    }

    @Override
    public void run() {
        while(true){
            mysl();
            wezWidelec();
            jedz();
            odloz();
        }
    }
}


