/**
 * Created by student1 on 2017-10-20.
 */
public class Main
{
    public static int zmienna;

    public static void main(String[] args)
    {
        System.out.println("Cze");

        Semaphore sc = new Semaphore();

        int n = 5;
        Thread[] threads = new Thread[n];
        Widelec[] widelce = new Widelec[n];

        for(int i = 0; i < n; i++){
            widelce[i] = new Widelec();
        }

        for(int i = 0; i < n; i++)
        {
            threads[i] = new Thread(new Filozof(widelce[i%n], widelce[(i+1)%n], i));
            threads[i].start();
        }

        for(int j = 0; j < n; j++)
        {
            try
            {
                threads[j].join();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
