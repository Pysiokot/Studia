/**
 * Created by student1 on 2017-10-20.
 */
public class MyRunnable implements Runnable {
    Semaphore sc;

    public MyRunnable(Semaphore sc){
        this.sc = sc;
    }

    public void run(){
        sc.decrement();
        for(int i = 0; i < 10000000; i++) {
            Main.zmienna++;
        }
        sc.increment();
    }
}


