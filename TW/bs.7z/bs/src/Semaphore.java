/**
 * Created by student1 on 2017-10-20.
 */
public class Semaphore {
    private int c = 1;


    public synchronized void increment(){
        c++;
        this.notifyAll();
    }

    public synchronized void decrement(){
        while (getValue() == 0){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        c--;
    }

    public synchronized int getValue(){
        return c;
    }
}
