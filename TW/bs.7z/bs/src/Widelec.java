public class Widelec{
    Semaphore s = new Semaphore();

    public void wez(){
        s.decrement();
    }

    public void odloz(){
        s.increment();
    }
}
